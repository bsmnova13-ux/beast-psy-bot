# Соломон — Telegram Bot

## Деплой на Railway

1. Зайди на railway.app и зарегистрируйся (можно через GitHub)
2. Нажми **New Project → Deploy from GitHub repo**
3. Загрузи эти файлы в GitHub репозиторий (или используй Railway CLI)
4. Railway автоматически найдёт Procfile и запустит бота

## Файлы
- `bot.py` — основной код бота
- `requirements.txt` — зависимости
- `Procfile` — инструкция для Railway
